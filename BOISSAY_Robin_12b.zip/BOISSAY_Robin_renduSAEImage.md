---
header-includes: \usepackage{color}
geometry: margin=30mm
fontsize: 17pt
---



# \hspace*{10em}SAE IMAGE


## Partie A

### A.0)  
Il faut augmenter la taille du fichier dans okteta de 1.  

### A.1)  
*Imgae0:*    
![dammier rouge](Image0.bmp){ width=64px }  
  
*code héxadécimal:*   
![image de l'hexadécimal de l'image](Image0_capture_okteta.png){ width=360px }  




### A.2)  
Le code hexadécimal ci-dessous représente L'image test: ![Imagetest](Imagetest.bmp){width=32px}  
![image héxa](_Imagetest_capture_okteta.png){ width=360px }  

### A.3)  
Le poid de l'image passe de 72 a 102.  
  
**1)**Il y a 24 bits par pixel car c'est toujours marqué 18 (1x16 + 8 = 24) à l'endroit qui indique il y a combien de bit par pixel.  
**2)**elle va de 36 jusqu'a 66 donc 48 octet. On peut aussi le deviner car c'est une image de 16 pixels et que chaque pixels est coder sur 3 octet donc 16x3 = 48.  
**3)**Non, les pixels sont toujours codées pareil.  
**4)**Les pixels sont toujours codé sur 3 octets.  

### A.4)  
  
**1)**Il y a 1 bit par pixels  
**2)**16 bits car l'image a 16 pixels et que chaque pixel est codé sur 1 bit.  
**3)**Oui, il y a une compression.  
**4)**Les couleurs sont codé sur 4 octets et se situe juste après l'entète du fichier.  
**5)**Il y a 2 couleurs dans la palette. Ici dans notre exemple c'est le rouge (00 FF FF 00) et le blanc (FF FF FF 00)  
**6)**Oui il a changé. Maintenant il faut codé un quartet pour chaque ligne de pixels et chaque bit de ce quartet représente un pixel.La couleur de ce pixel est soit blanc ou rouge. Dans notre cas un bit à 1 représente un pixel blanc et 1 bit à 0 représente un pixel rouge. 1 quartet représente une ligne de notre dammier. Cela donne donc:  

**R** = Rouge  
B = Blanc  
1010 -> A = B**R**B**R**  
0101 -> 5 = **R**B**R**B  
1010 -> A = B**R**B**R**  
0101 -> 5 = **R**B**R**B  

Cela nous donne notre dammier rouge et blanc.  

**7)**  
Il a juste fallu changé 00 00 FF 00(rouge) en FF 00 00 00(bleu).  
![](ImageBleue1_capture.png){ width=360px }  
  
**8)**   
J'ai inverser le blanc et le bleu de place ce qui à permis d'inverser le damier.  
![](ImageBleue2_capture.png){ width=360px }  
  
**9)**  
Le codage des pixels s'effectue ligne par ligne en commancant par en bas:  
**R** = Rouge  
B = Blanc  
0101 -> 5 = B**R**B**R**  
1111 -> F = **RRRR**  
1111 -> F = **RRRR**  
0000 -> 0 = BBBB  
![](Image3_capture.png){ width=360px } ![](Image3.bmp){ width=64px }  

**10)**  
Voici l'hexa de l'image du logo passé en index de couleur16:  
![](ImageExempleIndex16_capture.png){ width=360px }  
**11)**  
On peut trouver le nombre de couleur dans la palette à l'adresse 2E.  
Elle est dans notre cas de 10 soit 16 couleurs.  

**12)**  
On peut trouver le blanc à l'adresse 66.  
Celui-ci est codée par FE FE FD.  

**13)**  
Le tableau de pixels commence en 76, cette information est donnée à l'adresse 0A.  

**14)**  
Pour ajouter des pixels bleus en bas à gauche de l'image il m'as d'abord fallu trouver dans l'hexa quel était le numéro de la couleur bleu.  
Dans notre fichier la couleur qui se rapprocher le plus du bleu était DD C1 A2. C'étaut la couleur numéro 14 donc E.  
Ensuite j'ai remplacé les premier pixels qui était écrit en C pour du blanc par E pour du bleu.  
![](ImageBUT_capture_ligne_bleu.png){ width=256px }    

**15)**  
Cela diminue le nombre de couleur possible et donc diminue la qualité de l'image.  
Il ne reste plus que 4 couleurs possible qui sont: blanc, noir, bleu et gris.  
![](ImageExempleIndexBMP3_4.bmp){ width=256px }   
  


### A.5)  

**2)**  
j'ai changé le 04 00 00 00 en FC FF FF FF qui représente -4 en complément a 2 sur 32 bits.  
Cela a pour effet de retourner l'image.  
![](Image3_inverser_capture.png){ width=360px } ![Image3 inversé](Image3_inversé.bmp){ width=64px }  

**3)**  
La hauteur est initialement de A9 01 00 00(425), inversé cela donne -> 57 FE FF FF(-425).  
![Image_logo inversé](ImageExempleIndexBMP3_16_inverse.bmp){ width=256px }  

  

### A.6)  

**1)**    
Le poids du fichier est de 60 04 00 00 soit 1120 octets.  
Le poids à augmenter car il y a maintenant 256 couleurs possible et le codage des pixels a aussi changer. Cela est du à la compression en RLE.  

**2)**    
La position des pixels sont données en 0A sur 4 octets.  
Elle est 36 04 00 00.  

**3)**  
![Image4 hexa expliquation code pixel](Image4_capture_hexa.png){ width=360px }  

la couleur 0 représente le rouge et la couleur blanc est représenter par 1.  
01 00 veut dire qu'il y a 1 rouge. le premier octet représente le nombre de pixels et le deuxième représente la couleur qu'ils vont avoir.  
01 01 représente un blanc.  
Dans notre fichier okteta, nous avons 01 00  01 01  01 00  01 01  00 00.  
Tout ces octets représente la première ligne de notre image. Il y a un rouge puis un blanc puis un rouge puis un blanc.  
On met 00 00 pour dire que c'est la fin de ligne.  
**2ème ligne:** 01 01 01 00 01 01 01 00 00 00 1 blanc,1 rouge,1 blanc,1 rouge, fin de ligne.  
**3ème ligne:** 01 00 01 01 01 00 01 01 00 00 1 rouge,1 blanc,1 rouge,1 blanc, fin de ligne.  
**4ème ligne:** 01 01 01 00 01 00 01 01 00 00 1 blanc,1 rouge,1 blanc,1 rouge, fin de ligne.  

    

### A.7)  
**1)**    
Le poids de image5 est de 1102 octets. Il est plus léger que l'image4 grâce à la compression RLE.  
Cela s'explique car comme dans notre image il y a plusieurs fois ou des même pixels se suivent, la compression en RLE fait qu'ils faut moins de bits pour coder cette suite de même pixels. (1 ligne que de blanc et 2 lignes que de rouge).  

**2)**    
Le code des pixels est:  
1ère ligne: 04 00 00 00: 4 blancs puis fin de ligne.  
2ème ligne: 04 01 00 00: 4 rouges puis fin de ligne.  
3ème ligne: 04 01 00 00: 4 rouges puis fin de ligne.  
4ème ligne: 01 00 01 01 01 00 01 01 00 00: 1 blanc,1 rouge,1 blanc, 1 rouge, fin de ligne.  
Pour revenir sur le poids de l'image de la question d'avant, On voit bien que les lignes 1, 2 et 3 prennent chaqu'une 6 octets de moins soit 18 octes.  

    

### A.8)  
Il m'as fallu modifier la permière ligne (04 00 00 00).  
il faut que je remplace 4 blancs par: 2 blancs, 1 rouge,1 blanc.  
Cela donne donc: 02 00 01 01 01 00 00 00. 2 blancs,1 rouge,1 blanc, fin de ligne.  
J'ai également du modifier la taille de l'image qui est passée à 1106 octets.  

![image hexa nouvelle image](Image6_capture_hexa.png){ width=360px }  

    

### A.9)  
J'ai rajouter dans la palette de couleur du vert (00 FF 00 00) et du bleu (FF 00 00 00).  
Ensuite j'ai modifier le fichier okteta comme le montre le screen:  
Je n'ai pas du modifier la taille car elle n'as pas changée.   
![image7](Image7.bmp){ width=64px }  
![screen hexa image7](Image7_capture_hexa.png){ width=360px }    
 
  

### A.10)  
J'ai supprimer les 252*3 octets qui suivaient m'as dernière couleur écrite dans la palette afin de garder seulement 4 couleurs.  
J'ai du changer la taille a 106 octets et j'ai égalemment du changer l'offset du nombre de couleur de ma palette a 4.  
  
    
![](image8_capture.png){ width=64px }

![](Image9_capture_hexa.png){ width=360px }



   
\   
\   
\    
\   
\   
\   
\    

  
   
## Partie B Python  

\  
  
**B.1)**  
Pour transposer mon image j'ai eu besoin d'inverser les lignes et colonnes de mon images, j'ai donc récuperer un pixel au coordonnées x,y et je l'ai mis sur mon image de sortie au coordonnées y,x.  
![](Capture_b1.png){ width=350px }![](Imageout0.bmp){width=200px}  

\  
\   
  
**B.2)**  
pour inverser verticalment l'image, j'ai pris par rapport à chaque pixels, le pixel verticalment opposée à celui-ci.  
Pour faire cela avec le pixel x,y je devais prendre le pixel situé à la droite de mon image - la coordonnées x de celui-ci - 1 ce qui me donner le pixel inverse de mon pixel.  
![](Captureb2.png){width=350px}![](Imageout1.bmp){width=200px}  

\  
  
**B.3)**  
Pour mettre tout les pixels en gris j'ai rajouter une ligne ou je mettais le calcul donnée dans la sae dans une variable que j'ai nommé gris puis j'ai utiliser cette variable pour chaque R,G,V de mon pixels.  
![](captureb3.png){width=350px}![](Imageout2.bmp){width=200px}  

\  
  
**B.4)**  
J'ai repris le calcul données pour la disance euclidienne.  
J'ai mis une condition avec le calcul et en fonction de si elle était vrai ou non je remettais dans mon image un pixel blanc ou noir modéliser par un 0 ou un 1.  
![](captureb4.png){width=350px}![](Imageout3.bmp){width=200px}  
\  
  
**B.5)**  
J'ai regarder pour chaque pixels de mon image si au même coordonnée dans l'image du logo blanc et noir le pixel était blanc ou noir. En fonction du résultat je mettais une variable b à 0 ou 1.  
Après je changeais le dernier bit de la valeur rouge de chaque pixel de mon image du batiment de l'iut à 1 ou 0 en fonction de b.  
Cela m'as permis de cacher l'image du logo sans que ce soit visible à l'oil nue.  


![](captureb5_cacher.png){width=300px}![](Imageout_steg_1.bmp){width=200px}  

\   
\    
  
Ensuite il me suffisait de faire l'inverse, je regardais pour chaque pixel de la valeur rouge si il était à 0 ou 1 et avec ça j'ai pus recrée le logo en noir et blanc.  

![](captureb5_trouver.png){width=300px}![](Imageout4.bmp){width=200px}